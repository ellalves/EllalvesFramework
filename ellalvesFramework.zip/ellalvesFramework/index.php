<?php
//Se existe a sessão 
if (!isset($_SESSION)) {
    session_start();
}

//Configura se os erros vão ser mostrados ou n
error_reporting(E_ALL);
ini_set('display_errors', 1);
        
define("PROJECT_PATH", __DIR__); //Caminho absoluto para o projeto

define("APPPATH", "/App"); //Pasta onde ficam os arquivo 

//Caminho absoluto 
define("BASE_URL", "http://" . $_SERVER['HTTP_HOST'] . "/ellalvesFramework/");

//Insere o arquivo com o autoload
require_once PROJECT_PATH . '/vendor/autoload.php';

//Instancia a classe
$app = new Core\System();

//Chama o metodo que inicia o framework
$app->run();
