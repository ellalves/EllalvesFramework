<?php

namespace App\Configurations;
defined("APPPATH") OR die("Access denied");

class Config {
    //Banco de dados
    const DRIVER = "mysql";
    const HOST = "localhost";
    const USER = "root";
    const PASS = "";
    const DB_NAME = "my_mvc";
    const CHARSET = "utf8";
    
    /* Constantes da classe Bcrypt */
    const SALT_PREFIX = "2a"; // Default salt prefix
    const SALT_LENGNTH = 22; // Default hashing cost (4-31)  
    const DEFAULT_COST = 8; // Salt limit length
}
