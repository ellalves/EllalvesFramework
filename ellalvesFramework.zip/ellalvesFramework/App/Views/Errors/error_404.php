<!DOCTYPE html>
<html lang="ptbr">
    <head>
        <meta charset="utf-8" />
        <title>Erro 404 - Página não encontrada </title>
        <meta name="description" content="Página de erro 404, a página ṕrocurada não esta nos nossos servidores!" />
        <meta name="keywords" content="erro 404, não encontrado, sem resultado, inexistente" />
    </head>
    <body>
        <h2>Página não encontrada</h2>
        <div class="alert alert-danger"><strong><?php echo ERROR; ?></strong></div>
    </body>
</html>

