<!DOCTYPE html>
<html lang="ptbr">
    <head>
        <meta charset="utf-8" />
        <title> <?php echo $title; ?> </title>
        <meta name="description" content="<?php echo $description; ?>" />
        <meta name="keywords" content="<?php echo $keywords; ?>" />
        <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/bootstrap.min.css" />
        <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/font-awesome.min.css" />        
        <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/style.css" />        
        <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/style.login.css" />        
        <base href="<?php echo BASE_URL; ?>admin/" />
    </head>
    <body>