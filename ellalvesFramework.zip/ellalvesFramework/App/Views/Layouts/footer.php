        </div>
        <footer class="footer">
            <div class="container">
                <p class="text-muted">
                    Mini Frameworkcriado por <a href="https://ellalves.net.br"> Everton Alves </a> |
                    Sob a licença <a href="http://creativecommons.org/licenses/by-sa/4.0/" title="Pode ser usado livremente"><i class="fa fa-cc"></i> </a>
                </p>
            </div>
        </footer>
        <script src="<?php echo BASE_URL; ?>assets/js/jquery-2.2.3.min.js"></script>
        <script src="<?php echo BASE_URL; ?>assets/js/bootstrap.min.js"></script>

    </body>
</html>
