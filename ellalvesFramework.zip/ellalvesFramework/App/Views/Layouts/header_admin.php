<!DOCTYPE html>
<html lang="ptbr">
    <head>
        <meta charset="utf-8" />
        <title> <?php echo $title; ?> </title>
        <meta name="description" content="<?php echo $description; ?>" />
        <meta name="keywords" content="<?php echo $keywords; ?>" />
        <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/bootstrap.min.css" />
        <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/font-awesome.min.css" />        
        <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/style.css" />        
        <base href="<?php echo BASE_URL; ?>admin/" />
    </head>
    <body>
        <!-- Static navbar -->
        <nav class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="<?php echo BASE_URL; ?>/admin/panel">ADMIN</a>
                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav pull-right">
                        <li class="active"><a href="<?php echo BASE_URL; ?>"><i class="fa fa-home"></i> Home</a></li>
                        <li class="dropdown">
                            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false"> 
                                <i class="fa fa-user-secret"></i> <?php echo get_session('username') ?> <span class="caret"></span></a>
                            <ul class="dropdown-menu">
                                <li><a href="users/create">Cadastrar Usuários</a></li>
                                <li><a href="users">Listar Usuários</a></li>
                                <li><a href="groups/create">Cadastrar Grupos</a></li>
                                <li><a href="groups">Listar Grupos</a></li>
                                <li role="separator" class="divider"></li>
                                <li class="dropdown-header">Nav header</li>
                                <li><a href="panel">Painel</a></li>                                
                                <li><a href="users/logout">Sair</a></li>
                            </ul>
                        </li>
                    </ul>
                </div><!--/.nav-collapse -->
            </div>
        </nav>

        <div class="container-fluid">
