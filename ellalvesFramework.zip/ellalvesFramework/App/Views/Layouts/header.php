<!DOCTYPE html>
<html lang="ptbr">
    <head>
        <meta charset="utf-8" />
        <title> <?php echo $title; ?> </title>
        <meta name="description" content="<?php echo $description; ?>" />
        <meta name="keywords" content="<?php echo $keywords; ?>" />
        <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/bootstrap.min.css" />
        <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/font-awesome.min.css" />        
        <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/style.css" />        
        <base href="<?php echo BASE_URL; ?>" />
    </head>
    <body>
        <!-- Static navbar -->
        <nav class="navbar navbar-default navbar-static-top">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="#"> Meu site</a>
                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav">
                        <li class="active"><a href="#"> Home</a></li>
                        <li><a href="#about"> Sobre</a></li>
                        <li><a href="#contact"> Contato</a></li>
                        <?php if (!get_session('logged_in')): ?>
                        <li><a href="admin/users/login"> Entrar </a></li>
                        <?php else: ?>
                            <li><a href="admin/panel"> Painel</a></li>
                            <li><a href="admin/users/logout"> Sair</a></li>
                        <?php endif; ?>
                    </ul>
                </div><!--/.nav-collapse -->
            </div>
        </nav>

        <div class="container-fluid">