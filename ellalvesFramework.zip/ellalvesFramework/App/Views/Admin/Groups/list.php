<?php include 'App/Views/Layouts/header_admin.php'; ?>

<h2><?php echo $title;?> </h2>

<p><a href="groups/create" class="btn btn-success"><i class="fa fa-plus"></i> Novo</a></p>

<table class="table table-bordered table-hover table-responsive">
    <thead>
        <tr>
            <th>#</th>
            <th>Nome</th>
            <th>Descrição</th>
            <th>Estado</th>
            <th>Ação</th>
        </tr>
    </thead>
    <tbody>
        <?php if (!is_null($groups)): ?>
            <?php foreach ($groups as $g): ?>
                <tr>
                    <td><?php echo $g['id']; ?></td>
                    <td><?php echo $g['name']; ?></td>
                    <td><?php echo $g['description']; ?></td>
                    <td><?php echo status($g['status']); ?></td>
                    <td>
                        <a href="groups/edit/<?php echo $g['id']; ?>" class="btn btn-success"><i class="fa fa-edit"></i> Editar</a>
                        <a href="groups/delete/<?php echo $g['id']; ?>" class="btn btn-danger"><i class="fa fa-trash-o"></i> Deletar</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td>Nenhum registro para exibir!</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php include 'App/Views/Layouts/footer_admin.php'; ?>    