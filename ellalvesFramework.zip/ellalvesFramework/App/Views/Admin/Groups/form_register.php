<?php include 'App/Views/Layouts/header_admin.php'; ?>
<h2><?php echo $title;?> </h2>

<form action="<?php echo $action; ?>" method="POST">
    <div class="form-group col-md-8">
        <input type="text" id="name" name="name" value="<?php echo isset($group['name']) ? $group['name'] : ""; ?>" placeholder="Digite um nome para o grupo" class="form-control" />
    </div>
    <div class="form-group col-md-8">
        <input type="description" id="description" name="description" value="<?php echo isset($group['description']) ? $group['description'] : ""; ?>" placeholder="Digite uma breve descrição" class="form-control" />
    </div>
    <div class="form-group col-md-8">
        <select name="status" id="status"class="form-control" >
            <option value="active" <?php echo status_selected($group['status'], "active"); ?>> Ativo</option>
            <option value="inactive" <?php echo status_selected($group['status'], "inactive"); ?>> Inativo</option>
            <option value="pending" <?php echo status_selected($group['status'], "pending"); ?>> Pendente</option>
            <option value="delete" <?php echo status_selected($group['status'], "delete"); ?>> Deletado</option>
        </select>
    </div>
    <div class="form-group col-md-8">
        <a href="groups" title="Voltar para a listagem" class="btn btn-warning"><i class="fa fa-backward"></i> Voltar para a listagem </a>        
        <button type="submit" class="btn btn-success"><i class="fa fa-save"></i> Cadastrar </button>
    </div>
</form>
<?php include 'App/Views/Layouts/footer_admin.php'; ?> 