<?php include 'App/Views/Layouts/header_admin.php'; ?>
<h1><?php echo $teste;?></h1>
<?php include 'App/Views/Layouts/footer_admin.php'; ?>    