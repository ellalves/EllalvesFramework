<?php include 'App/Views/Layouts/header_blank.php'; ?>
<div class="wrapper">
    <div class="middle">
		<h2 style="text-align:center;"><a href="<?php echo BASE_URL; ?>"><i class="fa fa-home"></i>Home</a></h2>
        <form action="users/valid_login" method="POST">
            <div class="form-group">
                <input type="text" id="email" name="email" placeholder="Digite seu email" class="form-control" />
            </div>
            <div class="form-group">
                <input type="password" id="password" name="password" placeholder="Digite sua senha" class="form-control" />
            </div>
            <button type="submit" class="btn btn-primary"> Entrar </button>
        </form>
    </div>
</div>    
