<?php include 'App/Views/Layouts/header_admin.php'; ?>
<h2><?php echo $title;?> </h2>

<form action="<?php echo $action; ?>" method="POST">
    <div class="form-group col-md-8">
        <input type="text" id="username" name="username" value="<?php echo isset($user['username']) ? $user['username'] : ""; ?>" placeholder="Digite um nome de usuário" class="form-control" />
    </div>
    <div class="form-group col-md-8">
        <input type="email" id="email" name="email" value="<?php echo isset($user['email']) ? $user['email'] : ""; ?>" placeholder="Digite um E-mail válido" class="form-control" />
    </div>
    <div class="form-group col-md-8">
        <input type="password" id="password" name="password" placeholder="Insira uma senha" class="form-control" />
    </div>
    <div class="form-group col-md-8">
        <input type="password" id="confirm_password" name="confirm_password" placeholder="Confirme a senha" class="form-control" />
    </div>
    <div class="form-group col-md-8"class="form-control" >
        <select name="status" id="status" class="form-control">
            <option value="active" <?php echo status_selected($status, "active"); ?>> Ativo</option>
            <option value="inactive" <?php echo status_selected($status, "inactive"); ?>> Inativo</option>
            <option value="pending" <?php echo status_selected($status, "pending"); ?>> Pendente</option>
            <option value="delete" <?php echo status_selected($status, "delete"); ?>> Deletado</option>
        </select>
    </div>
    <div class="form-group col-md-8">    
        <button type="submit" class="btn btn-success"><i class="fa fa-save"></i> Cadastrar </button>
        <a href="users" title="Voltar para a listagem" class="btn btn-warning"><i class="fa fa-backward"></i> Voltar para a listagem </a>
    </div>
</form>
<?php include 'App/Views/Layouts/footer_admin.php'; ?> 