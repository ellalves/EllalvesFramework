<?php include 'App/Views/Layouts/header_admin.php'; ?>

<h2><?php echo $title;?> </h2>

<p><a href="users/create" class="btn btn-success"><i class="fa fa-plus"></i> Novo</a></p>

<table class="table">
    <thead>
        <tr>
            <th>#</th>
            <th>Usuário</th>
            <th>E-mail</th>
            <th>Criado em</th>
            <th>Estado</th>
            <th>Ação</th>
        </tr>
    </thead>
    <tbody>
        <?php if (!is_null($users)): ?>
            <?php foreach ($users as $u): ?>
                <tr>
                    <td><?php echo $u['id']; ?></td>
                    <td><?php echo $u['username']; ?></td>
                    <td><?php echo $u['email']; ?></td>
                    <td><?php echo date("d/m/Y H:m", strtotime($u['created_on'])); ?></td>
                    <td><?php echo status($u['status'], true); ?></td>
                    <td>
                        <a href="users/edit/<?php echo $u['id']; ?>" class="btn btn-success"><i class="fa fa-edit"></i> Editar</a>
                        <a href="users/delete/<?php echo $u['id']; ?>" class="btn btn-danger"><i class="fa fa-trash-o"></i> Deletar</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        <?php else: ?>
            <tr>
                <td>Nenhum registro para exibir!</td>
            </tr>
        <?php endif; ?>
    </tbody>
</table>
<?php include 'App/Views/Layouts/footer_admin.php'; ?>    