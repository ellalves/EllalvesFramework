<?php include 'App/Views/Layouts/header.php'; ?>
    <!-- Main jumbotron for a primary marketing message or call to action -->
    <div class="jumbotron">
      <div class="container">
        <h1>Olá!</h1>
        <p>Esse mini framework foi desenvolvido para estudar, seu uso em produção não é recomendado!</p>
        <p>Para aprender a usar basta observar os arquivos já existente, pois estão todos comentados!</p>
      </div>
    </div>
<?php include 'App/Views/Layouts/footer.php'; ?>    
