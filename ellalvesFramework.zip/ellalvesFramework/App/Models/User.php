<?php

namespace App\Models;

defined("APPPATH") OR die("Access denied");

use \Core\Model,
    App\Helpers\Bcrypt;

class User {

    protected $table = "users";
    protected $model;

    public function __construct() {
        $this->model = new Model(); //instancia da class Model
    }

    public function get_all($options, $first = false) {
        $users = $this->model->select($this->table, $options);
        return $first ? $this->model->first($users) : $users;
    }

    public function query($param) {
        $this->model->query($sql);
    }
    public function insert($param) {
        return $this->model->insert($this->table, $param);
    }

    public function update($fields, $conditions) {
        return $this->model->update($this->table, $fields, $conditions);
    }

    public function delete($cond) {
        return $this->model->delete($this->table, $cond);
    }

    public function last_id() {
        return $this->model->max_id($this->table);
    }

    public function is_unique(array $field) {
        return $this->model->unique_field($this->table, $field);
    }

    public function count_register($condition) {
        return $this->model->count_all($this->table, $condition);
    }

    public function verify_login($email, $password) {
        //Seleciona os dados no BD
        $data = $this->get_all(["fields" => ["id","password","username","email"], "where" => ["email" => $email]], true);
        
        //Verifica se retornou algum dado
        if (!is_null($data)) {
            //Confere a senha
            if (Bcrypt::check($password, $data['password'])) {
                return $data; //Retorna os dados
            }else{
                return "A senha não confere!"; //Caso contrario retorna o erro
            }
        } else { //Caso contrario retorna o erro
            return "Usuário não cadastrado";
        }
    }

}
