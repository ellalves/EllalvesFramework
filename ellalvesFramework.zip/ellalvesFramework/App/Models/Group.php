<?php

namespace App\Models;

defined("APPPATH") OR die("Access denied");

use \Core\Model;

class Group {

    protected $table = "groups";
    protected $model;

    public function __construct() {
        $this->model = new Model(); //instancia da class Model
    }

    public function get_all($options, $first = false) {
        $groups = $this->model->select($this->table, $options);
        return $first ? $this->model->first($groups) : $groups;
    }

    public function insert($param) {
        return $this->model->insert($this->table, $param);
    }

    public function update($fields, $conditions) {
        return $this->model->update($this->table, $fields, $conditions);
    }

    public function delete($cond) {
        return $this->model->delete($this->table, $cond);
    }
    public function last_id() {
        return $this->model->max_id($this->table);
    }

    public function is_unique(array $field) {
        return $this->model->unique_field($this->table, $field);
    }

    public function count_register($condition) {
        return $this->model->count_all($this->table, $condition);
    }
}
