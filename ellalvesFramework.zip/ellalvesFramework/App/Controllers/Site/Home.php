<?php

namespace App\Controllers\Site;
defined("APPPATH") OR die("Access denied");

use \Core\Controller,
    Core\View;

class Home extends Controller{
    
    public function __construct() {
        parent::__construct();
        
        $this->load_helper();
    }

    
    public function index() {

        View::set("title", "Página inicial");
        View::set("description", "Primeira pagina do site");
        View::set("keywords", "inicio, home, principal");
        View::render("Site/home");
    }
}
