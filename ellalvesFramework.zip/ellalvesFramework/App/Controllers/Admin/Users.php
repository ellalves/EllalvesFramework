<?php

namespace App\Controllers\Admin;

defined("APPPATH") OR die("Access denied");

use Core\Controller,
    App\Models\User,
    \Core\View,
    \App\Helpers\Bcrypt,
    \App\Helpers\Security;

/**
 * CRUD usuários
 *
 * @author ellalves
 */
class Users extends Controller {

    //Variavel que receberá a instancia da class User
    protected $user, $security;
    //Variaveis predefinida, antes de ser usada todas as variaveis devem ser declaradas globalmente
    protected $username, $email, $password, $confirm_password, $status;

    public function __construct() {
        //Herda o construtor da classe Controller e passa o metodo que os dados são passados
        parent::__construct("POST");
        //Coloca a instancia da classe numa variavel para proibir o acesso basta usar: $this->security->logged_in();
        $this->security = new Security();
        //Coloca a instancia da classe numa variavel global
        $this->user = new User();
        $this->load_helper();
    }

    public function index() {
        //Verifica se o usuario está logado
        $this->security->logged_in();
        $array = [
            "fields" => ["id", "username", "email", "created_on", "status"],
            //"where" => ["status" => "active"],
            // "group_by" => "id",
            "order_by" => "id asc",
                //"limit" => 3,
                //"offset"=>1
        ];
        
        $users = $this->user->get_all($array);

        View::set("title", "Listar usuários");
        View::set("description", "Listagem de usuários");
        View::set("keywords", "listagem, usuários, todos");
        View::set("users", $users);

        View::render("Admin/Users/list");
    }

    public function create() {
        View::set("title", "Cadastrar usuário");
        View::set("description", "Cadastro de usuário");
        View::set("keywords", "cadastrar, registrar, inscrever, usuário, senha, email");
        View::set("action", "users/store");
        View::set("status", "");
        View::render("Admin/Users/form_register");
    }

    public function store() {
        //Monta o array
        $opt = [
            "username" => $this->username,
            "email" => $this->email,
            "password" => Bcrypt::hash($this->password),
            "created_on" => date("Y-m-d H:i:s"),
            "status" => $this->status ? $this->status : "pending"
        ];

        if (!$this->user->is_unique(["username" => $this->username])) {
            $user = $this->user->insert($opt);
        }

        //Redireciona
        if ($user) {
            $msgm = "Registro inserido com sucesso!";
            $this->redirect("admin/users/index?msgm={$msgm}");
        } else {
            $error = "Registro não foi inserido!";
            $this->redirect("admin/users/index?error={$error}");
        }
    }

    public function edit($id) {
        $this->security->logged_in();
        View::set("title", "Editar usuário");
        View::set("description", "Edição de usuário");
        View::set("keywords", "editar, atualizar, modificar, usuário, senha, email");
        $cond = [
            'fields' => ['id', 'username', 'email', 'password','status'],
            'where' => ['id' => $id],
        ];
        $user = $this->user->get_all($cond, true);
        View::set("action", "users/update/" . $id);
        View::set("status", $user['status']);
        View::set("user", $user);
        View::render("Admin/Users/form_register");
    }

    public function update($id) {
        $this->security->logged_in();
        $fields = [
            "username" => $this->username,
            "email" => $this->email,
            "password" => \App\Helpers\Bcrypt::hash($this->password),
            "status" => $this->active
        ];

        if ($this->user->update($fields, ['id' => $id])) {
            $msgm = "Registro atualizado com sucesso!";
            $this->redirect("admin/users/index?msgm={$msgm}");
        } else {
            $error = "Registro não foi atualizado!";
            $this->redirect("admin/users/index?error={$error}");
        }
    }

    public function delete($id) {
        $this->security->logged_in();
        $cond = [
            "id" => $id
        ];

        if ($this->user->delete($cond)) {
            $msgm = "Registro deletado com sucesso!";
            $this->redirect("admin/users/index?msgm={$msgm}");
        } else {
            $error = "Registro não foi deletado!";
            $this->redirect("admin/users/index?error={$error}");
        }
    }

    public function login() {
        View::set("title", "Entrar");
        View::set("description", "Entrar na àrea restrita");
        View::set("keywords", "acesso, entrar, usuários");

        View::render("Admin/Users/login");
    }

    public function valid_login() {
        $login = $this->user->verify_login($this->email, $this->password);

        if (isset($login) && is_array($login)) {
            $this->security->set_session($login);
            $msgm = "Login efetuado com sucesso!";
            $this->redirect("admin/panel/index?msgm={$msgm}");
        } else {
            $this->redirect("admin/panel/index?error={$login}");
        }
    }

    public function logout() {
        if ($this->security->logout()) {
            $this->redirect("admin/users/login?$msgm=Você saiu!");
        }
    }

}
