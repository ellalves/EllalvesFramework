<?php

namespace App\Controllers\Admin;

defined("APPPATH") OR die("Access denied");

use Core\Controller,
    Core\View,
    App\Helpers\Security;

class Panel extends Controller {

    public function __construct() {
        parent::__construct();
        //Coloca a instancia da classe numa variavel para proibir o acesso basta usar: $this->security->logged_in();
        $this->security = new Security();
        
        $this->load_helper();
    }

    public function index() {
        //Verifica se o usuario está logado
        $this->security->logged_in();
        
        View::set("title", "Painel de Controle");
        View::set("teste", "Mensagem de teste!");
        View::render("Admin/panel");
    }

}
