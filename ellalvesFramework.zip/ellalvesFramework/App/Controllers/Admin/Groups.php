<?php

namespace App\Controllers\Admin;

defined("APPPATH") OR die("Access denied");

use Core\Controller,
    App\Models\Group,
    \Core\View,
    \App\Helpers\Security,
    \App\Helpers\MyHelpers;


class Groups extends Controller {
    
    //Variavel que receberá a instancia da class User
    protected $group, $security, $my_helpers;
    //Variaveis predefinida, antes de ser usada todas as variaveis devem ser declaradas globalmente
    protected $name, $description, $status;

    public function __construct() {
        //Herda o construtor da classe Controller e passa o metodo que os dados são passados
        parent::__construct("POST");
        //Coloca a instancia da classe numa variavel para proibir o acesso basta usar: $this->security->logged_in();
        $this->security = new Security();
        //Coloca a instancia da classe numa variavel global
        $this->group = new Group();
        //Insere o arquivo de helper
        $this->load_helper("My_helper");
        //Verifica se o usuario está logado
        $this->security->logged_in();        
    }
   
    public function index() {
        $array = [
            "fields" => ["id", "name", "description", "status"],
            "order_by" => "id asc",
        ];

        $groups = $this->group->get_all($array);

        View::set("title", "Listar grupos");
        View::set("description", "Listagem de grupos");
        View::set("keywords", "listagem, grupos, todos");
        View::set("groups", $groups);

        View::render("Admin/Groups/list");        
    }
    public function create() {
        View::set("title", "Cadastrar grupo");
        View::set("description", "Cadastro de grupo");
        View::set("keywords", "cadastrar, registrar, inscrever, grupo, senha, email");
        View::set("action", "groups/store");
        View::render("Admin/Groups/form_register");
    }

    public function store() {
        //Monta o array
        $opt = [
            "name" => $this->name,
            "description" => $this->description,
            "status" => $this->status ? $this->status : "pending"
        ];

        if (!$this->group->is_unique(["name" => $this->name])) {
            $group = $this->group->insert($opt);
        }

        //Redireciona
        if ($group) {
            $msgm = "Registro inserido com sucesso!";
            $this->redirect("admin/groups/index?msgm={$msgm}");
        } else {
            $error = "Registro não foi inserido!";
            $this->redirect("admin/groups/index?error={$error}");
        }
    }
    
    public function edit($id) {
        View::set("title", "Editar grupo");
        View::set("description", "Edição de grupo");
        View::set("keywords", "editar, atualizar, modificar, grupo, senha, email");
        $cond = [
            'fields' => ['id', 'name', 'description', 'status'],
            'where' => ['id' => $id],
        ];
        $group = $this->group->get_all($cond, true);
        
        //echo $this->my_helpers->status_selected($group['status']);
        
        View::set("action", "groups/update/" . $id);
        //View::set("selected", $group['status'] == "active" ?  "selected" : "");
        View::set("group", $group);
        View::render("Admin/Groups/form_register");
    }

    public function update($id) {
        $fields = [
            "name" => $this->name,
            "description" => $this->description,
            "status" => $this->status
        ];

        if ($this->group->update($fields, ['id' => $id])) {
            $msgm = "Registro atualizado com sucesso!";
            $this->redirect("admin/groups/index?msgm={$msgm}");
        } else {
            $error = "Registro não foi atualizado!";
            $this->redirect("admin/groups/index?error={$error}");
        }
    }
    public function delete($id) {
        $cond = [
            "id" => $id
        ];

        if ($this->group->delete($cond)) {
            $msgm = "Registro deletado com sucesso!";
            $this->redirect("admin/groups/index?msgm={$msgm}");
        } else {
            $error = "Registro não foi deletado!";
            $this->redirect("admin/groups/index?error={$error}");
        }
    }    
}
