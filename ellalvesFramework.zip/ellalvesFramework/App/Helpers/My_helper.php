<?php

function get_session($name) {
    $s = new \App\Helpers\Security();
    return $s->get_session($name);
}

function status_selected($status, $opt) {
    if($status == $opt) {
        return "selected=selected";
    } 
}

function status($status = "", $format = false) {
    switch ($status) {
        case "active":
            $status = "Ativo";
            $label = "success";
            break;
        case "pending":
            $status = "Pendente";
            $label = "warning";
            break;
        case "inactive":
            $status = "Inativo";
            $label = "danger";
            break;
        case "delete":
            $status = "Deletado";
            $label = "default";
            break;
        default :
            return ['active' => 'Ativo', 'pending' => 'Pendente', 'inactive' => 'Inativo', 'delete' => 'Deletado'];
    }

    if ($format === false) {
        return $status;
    } else {
        return "<span class='label label-$label'> $status </span>";
    }
}
