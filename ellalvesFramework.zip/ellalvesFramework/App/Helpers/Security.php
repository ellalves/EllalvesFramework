<?php

namespace App\Helpers;

defined("APPPATH") OR die("Access denied");

class Security {

    /**
     * Verifica se o usuario está logado
     */
    public function logged_in() {
        if (!$_SESSION['logged_in']) {
            $cont = new \Core\Controller();
            $cont->redirect("admin/users/login");
        }
    }

    /**
     * Coloca os dados informados numa sessão
     * @param array $array
     */
    public function set_session(Array $array) {
        if (is_array($array)) {
            foreach ($array as $k => $v) {
                $_SESSION[$k] = $v;
            }
            $_SESSION['logged_in'] = true;
        }
    }
    
    /**
     * Mostra o valor do item da sessão de acordo com a chave informada
     * @param string $session_name
     * @return string
     */
    public function get_session(string $session_name) {
        if (array_key_exists($session_name, $_SESSION)) {
            return $_SESSION[$session_name];
        }
    }

    /**
     * Elimina a sessão e desloga o usuario
     */
    public function logout() {
        if (isset($_SESSION['logged_in'])) {
            $_SESSION['logged_in'] = false;
            unset($_SESSION['logded_in']);
            return true;
        }
    }

}
