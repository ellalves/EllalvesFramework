<?php

namespace Core;

defined("APPPATH") OR die("Access denied");

class View extends System {

    protected static $data;
    protected $layout;

    public static function render($file) {
        $full_view = self::VIEWS_PATH . $file . self::EXTENSION_FILE; // Caminho completo ate o arquivo
        //Verifica se o arquivo existe
        if (!is_file($full_view)) {
            System::error_404("A view {$file} não existe, verifique os dados digitados!");
        }
        /*
         * Esta função irá ativar o buffer de saída. Enquanto o buffer de saída estiver ativo, 
         * não é enviada a saída do script (outros que não sejam cabeçalhos), 
         * ao invés a saída é guardada em um buffer interno.
         */
        ob_start();
        /* Se $data for um array
         * verifica cada chave e vê se ela tem um nome de variável válido. 
         * Também verifica por colisões com variáveis já existente na tabela de símbolo. 
         */
        is_array(self::$data) ? extract(self::$data) : [];
        require $full_view;
        $str = ob_get_contents(); //Retorna o conteúdo do buffer de saída
        ob_clean(); // Limpa (apaga) o buffer de saída e desativa o buffer de saída

        echo $str; //imprime o conteudo na tela
    }

    /**
     * Seta a chave e valor do array que será passado à view 
     * @param string $name
     * @param string $value
     * @return void
     */
    public static function set($name, $value) {
        self::$data[$name] = $value;
    }

}
