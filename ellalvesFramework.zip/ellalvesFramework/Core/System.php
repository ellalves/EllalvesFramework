<?php

namespace Core;

defined("APPPATH") OR die("Access denied");

class System extends Router {

    //Variaveis
    private $controller;
    private $method;
    private $params = [];

    //Constantes
    const NAMESPACE_CONTROLLERS = "\App\Controllers\\";
    const PATH_CONTROLLERS = "App/Controllers/";
    const VIEWS_PATH = "App/Views/";
    const EXTENSION_FILE = ".php";

    /**
     * Construtor
     */
    public function __construct() {
        $this->url = $this->get_url(); // Pega a url [get_url pertence a classe Router]
        $this->exists_controller(); //Verifica se o controlle existe

        $full_class = self::NAMESPACE_CONTROLLERS . $this->get_area() . "\\" . $this->get_controller(); //namespace

        $this->controller = new $full_class; //instancia a class
        $this->exists_method();

        //Pega os parametros
        $params = $this->url ? array_values($this->url) : [];
        $this->set_params($params); //Seta o valor 
    }

    public function exists_controller() {
        //Pega o nome do controle, se não tivr usa Home
        $controller = isset($this->url[0]) ? ucfirst($this->url[0]) : "Home";
        //Verifica se existe algum arquivo com o nome informado
        $full_file = self::PATH_CONTROLLERS . $this->get_area() . "/" . $controller . self::EXTENSION_FILE;
        if (file_exists($full_file)) {
            $this->set_controller($controller); // Atribui o nome ao controller
            unset($this->url[0]); //retira o item do array
        } else {
            $this->error_404("O controller {$controller} não existe, caminho: {$full_file} , verifique os dados digitados!");
        }
    }

    public function exists_method() {
        //Se tiver o segundo parametro verifica se eh um metodo
        $method = isset($this->url[1]) ? $this->url[1] : "index"; //// Atribui o valor/
        //Se o metodo existe retira o nome do metodo do arrray de urls
        if (method_exists($this->get_controller(), $method)) {
            $this->set_method($method);
            unset($this->url[1]);
        } else {
            $this->error_404("O método {$method} não existe, verifique os dados digitados!");
        }
    }

    /* Getters e setters */

    public function get_controller() {
        return $this->controller;
    }

    public function set_controller($controller) {
        return $this->controller = $controller;
    }

    public function get_method() {
        return $this->method;
    }

    public function set_method($method) {
        $this->method = $method;
    }

    public function get_params() {
        return $this->params;
    }

    public function set_params($params) {
        $this->params = $params;
    }

    /**
     * 
     * @param string $msgm - mensagme de erro
     * @return view com amensagem de erro formatada
     */
    public function error_404($msgm) {
        header("HTTP/1.0 404 Not Found");
        define("ERROR", $msgm);
        require_once self::VIEWS_PATH . "Errors/error_404" . self::EXTENSION_FILE; // inclui a pagina de erro
        exit;
    }

    /**
     * run - render renderizar o controlador / método que foi chamado com os parâmetros
     */
    public function run() {
        /**
         * Pode ser chamdo assim:
          $c = $this->get_controller();
          $c = new $c();
          $m = $this->get_method();
          $r = $c->$m();
         */
        //Ou assim:
        return call_user_func_array([$this->get_controller(), $this->get_method()], $this->get_params());
    }

}
