<?php

namespace Core;

defined("APPPATH") OR die("Access denied");

class Controller {

    public function __construct($method = null, $all = true) {
        //Pega os dados do $_POST
        if ($method == 'POST') {
            $this->post($method);
        }
        //Pega os dados do $_FILES
        $this->files($all);
    }

    /**
     * Permite chamar a s variaveis pelo nome usadono form, ex: se no form a var for username, 
     * para usá-la basta fazer $this->username, desde que seja explicitada na classe public/protected username 
     */
    private function post() {
        foreach ($_POST as $i => $v) {
            //Verifica se a propriedade existe na classe
            if (property_exists($this, $i)) {
                $this->$i = $v; // Atribui o valor à propriedade
            } else {
                unset($this->$i); //Elimina a propriedade
            }
        }
    }

    /**
     * Faz o mesmo com a função post com os dados de aqruivos
     * @param type $all
     */
    protected function files($all = true) {
        if (isset($_FILES)) {
            foreach ($_FILES as $i => $v) {
                if ($all || isset($this->$i)) {
                    $this->$i = $v;
                }
            }
        }
    }

    /**
     * Header Redirect
     *
     * Header redirect in two flavors
     * For very fine grained control over headers, you could use the Output
     * Library's set_header() function.
     *
     * @param	string	$uri	URL
     * @param	string	$method	Redirect method
     * 			'auto', 'location' or 'refresh'
     * @param	int	$code	HTTP Response status code
     * @return	void
     */
    function redirect($uri = '', $method = 'auto', $code = NULL) {
        // IIS environment likely? Use 'refresh' for better compatibility
        if ($method === 'auto' && isset($_SERVER['SERVER_SOFTWARE']) && strpos($_SERVER['SERVER_SOFTWARE'], 'Microsoft-IIS') !== FALSE) {
            $method = 'refresh';
        } elseif ($method !== 'refresh' && (empty($code) OR ! is_numeric($code))) {
            if (isset($_SERVER['SERVER_PROTOCOL'], $_SERVER['REQUEST_METHOD']) && $_SERVER['SERVER_PROTOCOL'] === 'HTTP/1.1') {
                $code = ($_SERVER['REQUEST_METHOD'] !== 'GET') ? 303 // reference: http://en.wikipedia.org/wiki/Post/Redirect/Get
                        : 307;
            } else {
                $code = 302;
            }
        }
        switch ($method) {
            case 'refresh':
                header('Refresh:0;url=' . BASE_URL . $uri);
                break;
            default:
                header('Location: ' . BASE_URL . $uri, TRUE, $code);
                break;
        }
        exit;
    }

    public function load_helper(string $name = "My_helper") {
        $path = PROJECT_PATH . APPPATH . '/Helpers/'.$name.'.php';
        if(is_file($path)){
            include $path; 
        }else{
            echo "ERRO: Arquivo {$name} não encontrado em: {$path}";
        }
    }
}
