<?php

namespace Core;

defined("APPPATH") OR die("Access denied");

class Model extends Database {

    /**
     * Construtor
     */
    public function __construct() {
        parent::__construct();
    }

    /**
     * Function select() - Faz a consulta ao BD 
     * @param string $table - Nome da tabela do BD
     * @param SQL $sql - Codigo SQL SELECT
     * @param Array $params - Array com os valores que serão substituido no código SQL passado
     * @return Array - Array com o resultado da consulta
     */
    public function query(string $sql, Array $params = []) {
        try {
            $pdo = $this->connection->prepare($sql); //Prepara os dados para serem inseridos
            $pdo->execute($params); //Executa
            //Retorna um array associativo com os nomes dos fields, sem o \PDO::FETCH_ASSOC, retornaria dados repetidos 
            return $pdo->fetchAll(\PDO::FETCH_ASSOC); // Semelhante a mysql_fetch_assoc
        } catch (\PDOException $e) {
            $msgm = "Não foi possivel fazer a seleção: " . $e->getMessage();
            System::error_404($msgm);
        }
    }

    public function select(string $table, Array $options = [], string $type = 'all') {
        $save['sql'] = '';
        $save['save'] = [];
        //Pega o array com os campos e converte numa string separada por virgulas
        $fields = $this->fields($options['fields']);

        //Condições separada por AND
        if (isset($options['where'])) {
            $ret = $this->get_fields($options['where'], " AND "); //lista de condições separadas por AND         
            $save['sql'] .= ' WHERE ' . $ret['sql']; // Concatena a expressão WHERE com o sql
            $save['save'] = array_merge($ret['save'], $save['save']); //Junta os arrays
        }

        //Condições separada por OR
        if (isset($options['or_where'])) {
            $ret = $this->get_fields($options['or_where'], " OR ");
            $save['sql'] .= ' WHERE ' . $ret['sql'];
            $save['save'] = array_merge($ret['save'], $save['save']);
        }

        //Agrupa os resultados
        if (isset($options['group_by'])) {
            $save['sql'] .= ' GROUP BY ' . $options['group_by'];
        }

        //Ordena os resultados
        if (isset($options['order_by'])) {
            $save['sql'] .= ' ORDER BY ' . $options['order_by'];
        }

        //Limit
        if (isset($options['limit'])) {
            $save['sql'] .= ' LIMIT ' . $options['limit'];
        }
        //Offset
        if (isset($options['offset'])) {
            $save['sql'] .= ' OFFSET ' . $options['offset'];
        }

        //Monta o sql
        $sql = 'SELECT ' . $fields . ' FROM `' . $table . '`' . $save['sql'] . ';';

        //Executa
        $this->pdo($sql, $save['save']);

        //Retorna de acordo com tipo
        return $this->type_query($type);
    }

    /**
     * Conta todos os registros da tabela
     * @param string $table - Nome da tabela a ser consultada
     * @param Array $where - Condição da consulta
     * @return int - Número de registros encontrados
     */
    public function count_all(string $table, Array $where = []) {
        return $this->select($table, ["where" => $where], "count");
    }
    
    /**
     * Conta os registro da tabela do BD, de acordo com o campo escolhido
     * @param string $table
     * @param array $where
     * @return  int - Número de registros encontrados
    
    public function count_field(string $table, Array $where) {
       // $field = array_keys($field);
        return $this->select($table, ["where"=> $where], "count");
    }
     */
    /**
     * Retorna o ultimo id da tabela do BD
     * @param string $table
     * @return int
     */
    public function max_id(string $table) {
        $last = $this->select($table,["fields" => ["MAX(id) as id"]], 'first'); //Faz a seleção
        return $last['id']; //Retorna o id
    }
    
    /**
     * Verifica se o registro é unico
     * @param string $table
     * @param array $field
     */
    public function unique_field(string $table, Array $field) {
        if($this->count_all($table, $field) == 1){
            return true;
        }else{
            return false;
        }
    }
    
    /**
     * 
     * @param array $array
     * @return type
     */
    public function first(Array $array) {
        if(isset($array[0]) && !is_null($array[0])){
            return $array[0];
        }else{
            return null;
        }
    }
    
    /**
     * 
     * @param string $table
     * @param array $options
     */
    public function insert(string $table, Array $options) {
        //Formata os fields para evitar SQL injection
        $save = $this->get_fields($options);
        //Pega os nimes dos fields digitados pelo usuario
        $fields = implode('`,`', array_keys($options));
        //Pega as variaveis que referenciam os valores que firam formatados na função get_field() 
        $values = implode(',', array_keys($save['save']));
        //Monta o SQL INSERT
        $sql = 'INSERT INTO `' . $table . '` (`' . $fields . '`) VALUES(' . $values . ');';
        //Executa e salva no BD
        $this->pdo($sql, $save['save']);
        
        return $this->max_id($table);
    }

    /**
     * Atualiza os registro da tabela do DB
     * @param string $table
     * @param array $fields
     * @param array $conditions
     */
    public function update(string $table, Array $fields, Array $conditions) {
        //Formata os fields
        $save = $this->get_fields($fields);
        //Formata a condição, geralmente será o id mas pode ser qualquer campo.
        //Retorna algo do tipo: Array ( [sql] => `id` = :id [save] => Array ( [:id] => 2 ) ) 
        $cond = $this->get_fields($conditions);

        $save['save'] = array_merge($save['save'], $cond['save']);
        $sql = "UPDATE `" . $table . "` SET " . $save['sql'] . " WHERE " . $cond['sql'];

        return $this->pdo($sql, $save['save']);
    }

    /**
     * 
     * @param string $table
     * @param array $conditions
     */
    public function delete(string $table, Array $conditions) {
        $save = $this->get_fields($conditions);
        $sql = "DELETE FROM `" . $table . "` WHERE " . $save['sql'];
        return $this->pdo($sql, $save['save']);
    }

}
