<?php

namespace Core;

defined("APPPATH") OR die("Access denied");

class Router {

    protected $url;
    protected $areas = [
        "site" => "Site",
        "admin" => "Admin"
    ];
    protected $area;

    /**
     * get_url - recebe a url e retorna um array
     * @return array
     */
    public function get_url() {
        //Se a url não está vazia separa por '/' num array, do contrario, usa o valor padrão
        $url = isset($_GET['url']) ? explode("/", filter_var(rtrim($_GET['url']), FILTER_SANITIZE_URL)) : ["home", "index"];
        //Se o usuario digitou a area verifica e retira do array
        if (array_key_exists($url[0], $this->areas)) {
            $this->set_area($url[0]); //Pega o valor da area caso exista
            unset($url[0]); //retira o nome da area do array
            
            return array_values(array_filter($url)); //Remove elementos nulo, vazios e retorna os valores do array
        } else { //Do contrario usa a area padrão definida na classe Router
            $this->set_area($this->areas['site']);
            
            return array_filter($url); //Remove elementos nulo, vazios e retorna
        }
    }

    public function get_area() {
        return $this->area;
    }

    public function set_area($area) {
        return $this->area = ucfirst($area);
    }

}
