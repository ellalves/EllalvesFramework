<?php

namespace Core;

defined("APPPATH") OR die("Access denied");

use \App\Configurations\Config;

class Database extends Config {

    protected $connection, $mysql_exec;

    /**
     * Construtor - Faz a conexão com o BD
     */
    public function __construct() {
        try {
            $this->connection = new \PDO(self::DRIVER . ":host=" . self::HOST . ";dbname=" . self::DB_NAME, self::USER, self::PASS);
            $this->connection->setAttribute(\PDO::ATTR_ERRMODE, \PDO::ERRMODE_EXCEPTION);
            $this->connection->exec("SET NAMES " . self::CHARSET);
        } catch (PDOException $e) {
            $msgm = "A conexão Falhou: " . $e->getMessage();
            System::error_404($msgm);
        }
    }

    /**
     * Formata os campos para inserir no BD
     * @param array $fields - Campos do BD
     * @return Array $save - Array com os campos e os valores formatados
     */
    protected function get_fields(Array $fields, $caractere = ",") {
        $array['sql'] = ''; //inicia p array
        //Faz o loop concatenando cada chave ao valor formatados no estilo: sql -  `chave` = :chave e save - :chave = valor
        foreach ($fields as $key => $value) {
            $array['sql'] .= '`' . $key . '` = :' . $key . ' ' . ($value != end($fields) ? $caractere : "");
            $array['save'][':' . $key] = $value;
        }

        return $array;
    }

    /**
     * Retorna o resultado da consulta de acordo com o tipo escolhido
     * @param string $type
     * @return array or numeric
     */
    protected function type_query(string $type = "") {
        switch ($type) {
            case "first": //Retorna o primeiro registro da consulta 
                $type_query = $this->mysql_exec->fetch(\PDO::FETCH_ASSOC);
                break;
            case "count": //Retorna o numero de registro
                $type_query = $this->mysql_exec->rowCount();
                break;
            default: //Retorna todos os dados consultados
                $type_query = $this->mysql_exec->fetchAll(\PDO::FETCH_ASSOC);
                break;
        }

        return $type_query;
    }

    /**
     * Converte o array de campos para uma string separada por virgulas
     * @param type $fields
     * @return string
     */
    protected function fields($fields) {
        if (is_array($fields)) {
            $ret = implode(",", $fields);
        } else {
            $ret = "*";
        }
        return $ret;
    }

    /**
     * Executa a query com segurança
     * @param string $sql
     * @param array $values
     */
    protected function pdo(string $sql, Array $values) {
        try {
            $dbh = $this->pdo_prepare($sql); //Sql fomatado
            $this->connection->beginTransaction(); //Comece uma transação, desligue o autocommit
            $this->pdo_bind_value($values);
            $this->pdo_execute($values); //Executa a query com os valore informados
            $this->connection->commit(); //Comprometer as mudanças
        } catch (PDOException $e) {
            $this->connection->rollBack(); //Reconheçe o erro e reverte as mudanças
            die("Erro: " . $e->getMessage());
        }
    }

    /**
     * Prepara a query
     * @param string $sql
     */
    protected function pdo_prepare(string $sql) {
        //Prepara o SQL e guarda o resultado na variavel mysql_exec
        $this->mysql_exec = $this->connection->prepare($sql);
    }

    /**
     * Atribui a chave aos valores pre-formatados
     * @param array $values
     */
    protected function pdo_bind_value(Array $values) {
        //
        foreach ($values as $k => $v) {
            $this->mysql_exec->bindValue(':' . $k, $v);
        }
    }

    /**
     * Executa a query
     * @param array $values
     */
    protected function pdo_execute(Array $values = []) {
        $this->mysql_exec->execute($values);
    }

}
